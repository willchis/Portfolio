﻿
var getFeeds = function () {
  $('#base').html('');
  var XMLHttpRequestObject = new XMLHttpRequest();
    XMLHttpRequestObject.open("GET", "http://labs.durabledigital.com/will/home/GetFeed", false);
    XMLHttpRequestObject.onreadystatechange = function () {
      var cameras;
      if (this.readyState != 4) return;
      if (this.status == 200) {
        var xmlDocument = this.responseXML,
          isAvailable = false,
          location = "",
          link;
        cameras = xmlDocument.getElementsByTagName("camera"); // firefox tels me here "TypeError xmlDocument is null"
        for (var i = 0; i < cameras.length; i++) {
          isAvailable = cameras[i].attributes[1].nodeValue;
          if (isAvailable === 'true') {
            link = "http://www.tfl.gov.uk/tfl/livetravelnews/trafficcams/cctv/" + cameras[i].children[3].innerHTML;
            location = cameras[i].children[1].innerHTML;
            $('#base').append('<img id="'+ i + '" src="' + link + '" onclick="refreshImg(\''+ link +'\', ' + i + ', \'' + location + '\')" data-location="' + location + '"/>');
          }
        }
      }
    }
  XMLHttpRequestObject.send(null);
};

var refreshImg = function (link, id, location) {
  $('#' + id).fadeOut(1000, function () {
    $('#' + id).replaceWith('<img id="' + id + '" src="' + link + '" style="display:none;" onclick="refreshImg(\'' + link + '\', ' + id + ')" data-location="' + location + '"/>');
    $('#' + id).fadeIn(2000);
  });
};


$(function () {
  $('#searcher').on('keypress', function (e) {
    if (e.keyCode === 13) {
      filter($('#searcher').val());
    }
  });

  var filter = function (text) {
    var loc = "";
    $('img:not(#spinner)').each(function () {
      $(this).show();
      loc = $(this).data('location');
      if (loc.toLowerCase().indexOf(text.toLowerCase()) > -1) {
        $(this).show();
      } else {
        $(this).hide();
      }
    });
  };
});
