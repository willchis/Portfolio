
var camUrl = "cameralist.xml"
var camLive = "http://www.tfl.gov.uk/tfl/livetravelnews/trafficcams/cctv/jamcams-camera-list.xml"

$(function(){
	var liveCamCount
	
	$.get(camLive, function(xml) {
		$(xml).find('camera').each(function(){
			if($(this)[0].getAttribute('available').nodeValue === 'true') {
				var link = "http://www.tfl.gov.uk/tfl/livetravelnews/trafficcams/cctv/" + $(this).find('file').text();
				$('#base').append('<img src="' + link + '"/>');
			};
		});
	});
	
});
